# CSCI3345-S18-Play-InClass

This is the in-class code using Play for CSCI 3345 in Spring 2018. It was built off of the [Play starter application](https://github.com/playframework/play-scala-starter-example/tree/2.6.x).
